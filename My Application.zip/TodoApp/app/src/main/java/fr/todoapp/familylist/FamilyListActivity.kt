package fr.todoapp.familylist

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import fr.todoapp.R

class FamilyListActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_family_list)
    }
}