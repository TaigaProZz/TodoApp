package fr.todoapp

data class Task (
    val taskName: String,
    val isChecked: Boolean = false
    )